ONLINE INVENTORY SYSTEM

**************************************************************************************************************************
DESCRIPTION: EMPLOYEES AND MANAGERS CAN CREATE ACCOUNTS AND LOG IN. EMPLOYEES CAN VIEW INVENTORY, CREATE NEW PRODUCTS, 
SELL PRODUCTS, AND VIEW INVENTORY REPORTS. MANAGERS HAVE ALL THE FUNCTIONALITIES OF EMPLOYEES, WITH THE ADDITIONAL ABILITY 
TO PURCHASE PRODUCTS."

**************************************************************************************************************************
EXTERNAL LIBRARIES IN THE PROJECT: 1. IMPLEMENTING A RESTFUL API USING THE CROW C++ FRAMEWORK
                                   2. IMPLEMENTING DATABASE CRUD OPERATIONS USING THE SQLITE3 LIBRARY 


**************************************************************************************************************************
COMPILE AND RUN THE SYSTEM

1. GO TO THE BACKEND EXE FOLDER AND RUN THE BACK_END.EXE FILE.

2. OPEN A TERMINAL, CD TO THE PATH OF THE FRONT_END FOLDER AND RUN NPM START. (HINT: IF YOU DON'T HAVE NodeJS INSTALL,
GO TO https://nodejs.org/en AND DOWNLOAD Node.js(LTS).

3. WHEN THE FRONT_END RUNS, YOU WILL SEE THE LOGIN PAGE IN YOUR BROWSER. IF YOU DON'T HAVE ACCOUNT, CLICK THE REGISTER 
BUTTON TO CREATE AN ACCOUNT. 
























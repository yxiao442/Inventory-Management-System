Instruction

Go to backend exe folder, run the back_end.exe file.

open a terminal, cd to the path of the front_end folder which is pulled from the GitHub. Run npm start.

if you don't install the node.js, go to https://nodejs.org/en and download Node.js(LTS).

